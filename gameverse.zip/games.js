const games = [
  { title: "Elder Realms", description: "Explore terras místicas e enfrente dragões épicos!", image: "img/game1.jpg", link: "detalhes.html?game=elder-realms" },
  { title: "Speed Racer X", description: "Velocidade máxima em corridas futuristas!", image: "img/game2.jpg", link: "detalhes.html?game=speed-racer-x" }
];